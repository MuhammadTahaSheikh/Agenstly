import React from 'react'
import "./NavbarTab.css"
function NavbarTab() {
  return (
    <div>NavbarTab</div>
  )
}

export default NavbarTab